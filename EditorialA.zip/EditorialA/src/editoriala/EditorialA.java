/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package editoriala;

import vista.Bienvenida;

public class EditorialA {
    
    public static void main(String[] args) {
        Bienvenida bi = new Bienvenida();
        bi.setVisible(true);
    }  
}
